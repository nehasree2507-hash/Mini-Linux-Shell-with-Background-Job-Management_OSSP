# mysh — Mini Linux Shell with Background Job Management

A small Unix shell written in C using only POSIX system calls. It executes commands, runs
background jobs, lists them, and terminates them — with correct process-group, signal and
terminal handling, the same mechanisms real shells such as bash use.

## Features

| Capability | How to use it |
|---|---|
| Run commands | `ls -l /tmp`, `echo "quoted  args"` |
| Redirection | `cmd < in.txt`, `cmd > out.txt`, `cmd >> out.txt` |
| Background jobs | `sleep 100 &` → prints `[1] <pid>` |
| Job listing | `jobs` |
| Process termination | `kill %1`, `kill -KILL %2`, `kill <pid>` |
| Foreground / background control | `fg %1`, `bg %1`, **Ctrl-Z** (stop), **Ctrl-C** (interrupt) |
| Automatic completion notices | `[1] 4242  Done  sleep 2` appears before the next prompt |
| Built-ins | `cd`, `jobs`, `fg`, `bg`, `kill`, `help`, `exit` |

## Requirements

- Linux (or any POSIX system), `gcc` or `clang`, `make`
- `python3` and `bash` (only for running the test suite)

## Build

```bash
git clone <your-repo-url>
cd <repo>
make            # produces ./mysh
```

Without make: `gcc -Wall -Wextra -O2 -o mysh src/mysh.c`

## Run

```bash
./mysh
mysh> help
```

### Example session

```
mysh> echo Hello from mysh
Hello from mysh
mysh> sleep 60 &
[1] 564
mysh> sleep 2 &
[2] 565
mysh> jobs
[1] 564      Running            sleep 60
[2] 565      Running            sleep 2
mysh> kill %1
sent Terminated to [1] 564
[1] 564      Terminated         sleep 60
mysh> sleep 3
[2] 565      Done               sleep 2
mysh> exit
```

## Command reference

| Command | Description |
|---|---|
| `cmd args… [&]` | Run an external program; trailing `&` runs it in the background |
| `jobs` | List all jobs with ID, PID, state and command |
| `fg [%n]` | Resume job *n* (default: most recent) in the foreground |
| `bg [%n]` | Resume a stopped job *n* in the background |
| `kill [-SIG] %n \| pid …` | Send a signal (`TERM` default; names such as `KILL`, `INT`, `STOP`, `CONT`, `HUP` or numbers) |
| `cd [dir]` | Change directory (`$HOME` if omitted) |
| `help` | Print built-in help |
| `exit` / Ctrl-D | Quit; remaining jobs are sent SIGTERM |

## Testing

```bash
make test
```

- `tests/run_tests.sh` — 26 scripted tests (execution, quoting, redirection, jobs, kill, error handling, zombies, exit cleanup)
- `tests/pty_tests.py` — 7 interactive tests run in a pseudo-terminal (Ctrl-C, Ctrl-Z, `fg`, `bg`, killing stopped jobs, terminal ownership)

Expected result: `passed: 26 failed: 0` and `passed: 7 failed: 0`.

All tests are safe: they only start `sleep`, `cat`, `echo` and similar commands, and only signal
processes that `mysh` itself created.

## Repository layout

```
src/mysh.c            shell source (single file, ~500 lines)
tests/run_tests.sh    scripted tests
tests/pty_tests.py    pseudo-terminal tests for job control
docs/REPORT.md        project report (design, implementation, testing)
docs/DEMO.md          step-by-step live-demo script
docs/presentation.pptx  slides
Makefile
```

## Design in brief

- Each command runs in its **own process group** (`setpgid`), so signals and terminal access
  are isolated per job and `kill %n` reaches every process in the job.
- A fixed **job table** (64 entries) tracks PID, state and command.
- A **SIGCHLD handler** updates job states with `waitpid(WNOHANG|WUNTRACED|WCONTINUED)` so
  finished background jobs never become zombies; it only edits the table (async-signal-safe) —
  printing happens before the next prompt.
- SIGCHLD is **blocked** around `fork`/foreground `waitpid` to avoid races.
- The shell **ignores** SIGINT/SIGTSTP/SIGTTOU and hands the terminal to the foreground job with
  `tcsetpgrp`, so Ctrl-C / Ctrl-Z affect only that job.

See [docs/REPORT.md](docs/REPORT.md) for the full write-up.

## Limitations

No pipes (`|`), command lists (`;`, `&&`), variable expansion, globbing or command history.
Maximum 64 concurrent jobs, 1023-character lines.

## Team

| Member | Role / contribution |
|---|---|
| _Name 1_ | _e.g. command parsing, redirection_ |
| _Name 2_ | _e.g. job table, SIGCHLD handling_ |
| _Name 3_ | _e.g. fg/bg/kill, terminal control_ |
| _Name 4_ | _e.g. testing, documentation_ |

## License

Educational project. Add the license your course requires (e.g. MIT).
